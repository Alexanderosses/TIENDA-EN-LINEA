import axios from 'axios';

export const createMercadoPagoPreference = async (items, payer, backUrls, autoReturn, accessToken) => {
  const response = await axios.post(
    'https://api.mercadopago.com/checkout/preferences',
    {
      items,
      payer,
      back_urls: backUrls,
      auto_return: autoReturn,
    },
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
    }
  );

  return response.data;
};
