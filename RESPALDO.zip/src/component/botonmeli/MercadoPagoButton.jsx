import { Button } from 'react-bootstrap';

export const MercadoPagoButton = ({ isLoggedIn, onBuyClick }) => {
  const handleBuyClick = () => {
    if (isLoggedIn) {
      // Agrega aquí la lógica de Mercado Pago según la documentación de Mercado Pago
      console.log('Iniciar proceso de compra con Mercado Pago');
    } else {
      console.log('Usuario no logeado. Mostrar mensaje o realizar acciones necesarias.');
    }
  };

  return (
    <Button
      variant="success"
      disabled={!isLoggedIn}  {/* Asegúrate de que esta línea esté bien */}
      onClick={onBuyClick}
      className="mt-3"
    >
      Comprar con MercadoPago
    </Button>
  );
};