/* MENU */
export const menuList = [
    {item: 'Home', url:'/'},
    {item: 'Modelos', url:'/Modelos'},
    {item: 'Reserva', url:'/Reservation'},
    {item: 'Contacto', url:'/Contact'},
]


